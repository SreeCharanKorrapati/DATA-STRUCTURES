#include<iostream>
using namespace std;
int sum=0;
int sumn(int n)
{
    if(n>0)
    {
        sum+=n;
        sumn(n-1);
    }
    return sum;
}
int main()
{
    int x=3;
    cout << sumn(x);
    return 0;
}
