#include<iostream>
using namespace std;
int m=1;
int fact(int d)
{
    if(d==0 || d==1)
    {
        return 1;
    }
    if(d>1)
    {
        m*=d;
        return fact(d-1);
    }
    return m;
}
int c(int n,int r)
{
    int t1,t2,t3,t4;
    t1=fact(n);
    t2=fact(r);
    t3=fact(n-r);
    t4=t2*t3;
    return t1/t4;
}
int main()
{
    int x=3,y=3;
    cout << c(x,y);
    return 0;
}
