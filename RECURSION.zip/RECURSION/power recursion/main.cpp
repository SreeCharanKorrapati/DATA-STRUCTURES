#include <iostream>
using namespace std;
int power(int m,int n)
{
    if(n==0)
    {
        return 1;
    }
    if(n>0)
    {
        return power(m,n-1)*m;
    }
}

int main()
{
    int x=4,y=2;
    cout << power(x,y);
    return 0;
}
