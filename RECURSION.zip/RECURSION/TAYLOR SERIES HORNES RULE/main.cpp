#include<iostream>
using namespace std;
double e(double x,double n)
{
    static double s=1;
    if(n==0)
        return s;
    s=1+(x/n)*s;
    e(x,n-1);
    return s;
}
int main()
{
    double r=e(2,10);
    cout << r ;
    return 0;
}
