#include<iostream>
using namespace std;
double e(int x,int n)
{
    double r;
    static double p=1,f=1;
    if(n==0)
    {
        return 1;
    }
    else
    {
        r=e(x,n-1);
        p=p*x;
        f=f*n;
        return r+(p/f);
    }
}
int main()
{
    double a=1,b=10;
    double c=e(a,b);
    cout << c ;
    return 0;
}
