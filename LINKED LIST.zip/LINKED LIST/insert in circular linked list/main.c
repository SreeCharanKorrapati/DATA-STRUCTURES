#include <stdio.h>
#include <stdlib.h>
struct node
{
    int data;
    struct node * next;
}*head;
void create(int arr[],int n)
{
    int i;
    struct node *t,*last;
    head=(struct node*)malloc(sizeof(struct node));
    head->data=arr[0];
    head->next=head;
    last=head;
    for(i=1;i<n;i++)
    {
        t=(struct node*)malloc(sizeof(struct node));
        t->data=arr[i];
        t->next=last->next;
        last->next=t;
        last=t;
    }
}
void display(struct node * h)
{
    do
    {
        printf("%d->",h->data);
        h=h->next;
    }while(h!=head);
}
void insert(struct node *h,int pos,int n)
{
    struct node *t,*p=head;
    t=(struct node*)malloc(sizeof(struct node));
    t->data=n;
    if(pos==0)
    {
        t->next=head;
        do
        {
            p=p->next;
        }while(p->next!=head);
        p->next=t;
        head=t;
    }
    else
    {
        for(int i=0;i<pos-1;i++)
        {
            p=p->next;
        }
        t->next=p->next;
        p->next=t;
    }
}
int main()
{
    int arr[]={5,10,15,20,25};
    create(arr,5);
    insert(head,2,6);
    display(head);
    return 0;
}
