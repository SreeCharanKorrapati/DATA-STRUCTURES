#include <stdio.h>
#include <stdlib.h>
struct node
{
    int data;
    struct node*next;
}*head;
void create(int arr[],int n)
{
    struct node*last,*t;
    int i;
    head=(struct node*)malloc(sizeof(struct node));
    head->data=arr[0];
    head->next=head;
    last=head;
    for(i=1;i<n;i++)
    {
        t=(struct node*)malloc(sizeof(struct node));
        t->data=arr[i];
        t->next=last->next;
        last->next=t;
        last=t;
    }
}
void display(struct node *p)
{
    do
    {
        printf("%d-> ",p->data);
        p=p->next;
    }while(p!=head);
    printf("\n");
}
void delete(struct node*p,int pos)
{
    struct node *q=head;
    if(pos==0)
    {
        do
        {
            q=q->next;
        }while(q->next!=head);
        q->next=head->next;
        int x=head->data;
        free(head);
        head=q->next;
    }
    else
    {
        for(int i=0;i<pos-2;i++)
        {
            p=p->next;
        }
        q=p->next;
        p->next=q->next;
        free(q);
    }
}
int main()
{
    int arr[]={5,10,15,20,25};
    create(arr,5);
    delete(head,2);
    display(head);
    return 0;
}
