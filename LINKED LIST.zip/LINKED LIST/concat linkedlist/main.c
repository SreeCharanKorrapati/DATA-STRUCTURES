#include <stdio.h>
#include <stdlib.h>
struct node
{
    int data;
    struct node *next;
}*first=NULL,*second=NULL,*third;
void create(int a[],int n)
{
    int i;
     struct node *t,*last;
     first=(struct node*)malloc(sizeof(struct node));
     first->data=a[0];
     first->next=0;
     last=first;
     for(i=1;i<n;i++)
     {
         t=(struct node*)malloc(sizeof(struct node));
         t->data=a[i];
         t->next=0;
         last->next=t;
         last=t;
     }
}

void create2(int a[],int n)
{
    int i;
     struct node *t,*last;
     second=(struct node*)malloc(sizeof(struct node));
     second->data=a[0];
     second->next=0;
     last=second;
     for(i=1;i<n;i++)
     {
         t=(struct node*)malloc(sizeof(struct node));
         t->data=a[i];
         t->next=0;
         last->next=t;
         last=t;
     }
}
void display(struct node*p)
{
      while(p!=NULL)
      {
          printf("%d->",p->data);
          p=p->next;
      }
}
void concat(struct node *p,struct node *q)
{
    third=p;
    while(p->next!=NULL)
    {
        p=p->next;
    }
    p->next=q;
}
int main()
{
    int a[]={5,10,15,20,25};
    int b[]={6,12,18,24,30};
    create(a,5);
    create2(b,5);
    printf("First linkedlist : \n");
    display(first);
    printf("\nSecond linkedlist : \n");
    display(second);
    printf("\nConcatinated List : \n");
    concat(first,second);
    display(third);
    return 0;
}
