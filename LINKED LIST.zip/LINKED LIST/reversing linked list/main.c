#include <stdio.h>
#include <stdlib.h>
struct node
{
    int data;
    struct node *next;
}*first=NULL;
void create(int a[],int n)
{
    int i;
     struct node *t,*last;
     first=(struct node*)malloc(sizeof(struct node));
     first->data=a[0];
     first->next=0;
     last=first;
     for(i=1;i<n;i++)
     {
         t=(struct node*)malloc(sizeof(struct node));
         t->data=a[i];
         t->next=0;
         last->next=t;
         last=t;
     }
}
void display(struct node*p)
{
      while(p!=NULL)
      {
          printf("%d->",p->data);
          p=p->next;
      }
}
void reverse(struct node *p)
{
    struct node *q,*r,*s;
    s=first;
    while(s!=NULL)
    {
        q=r;
        r=s;
        s=s->next;
        r->next=q;
    }
    first=r;
}
int main()
{
    int a[]={5,10,15,20,25};
    create(a,5);
    display(first);
    reverse(first);
    printf("\n");
    display(first);
    return 0;
}
