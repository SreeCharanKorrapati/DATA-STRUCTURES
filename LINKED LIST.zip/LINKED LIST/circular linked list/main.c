#include <stdio.h>
#include <stdlib.h>
struct node
{
    int data;
    struct node * next;
}*head;
void create(int arr[],int n)
{
    int i;
    struct node*t,*last;
    head=(struct node*)malloc(sizeof(struct node));
    head->data=arr[0];
    head->next=head;
    last=head;
    for(i=1;i<n;i++)
    {
        t=(struct node*)malloc(sizeof(struct node));
        t->data=arr[i];
        t->next=last->next;
        last->next=t;
        last=t;
    }
}
void display(struct node *h)
{
    do
    {
        printf("%d->",h->data);
        h=h->next;
    }while(h!=head);
    printf("\n");
}
int main()
{
    int arr[]={5,10,15,20,25};
    create(arr,5);
    display(head);
    return 0;
}
