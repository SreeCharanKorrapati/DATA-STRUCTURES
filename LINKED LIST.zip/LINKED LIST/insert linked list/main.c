#include <stdio.h>
#include <stdlib.h>
struct node
{
    int data;
    struct node * next;
}*first=NULL;
void create(int arr[],int n)
{
    int i;
    struct node*t,*last;
    first=(struct node*)malloc(sizeof(struct node));
    first->data=arr[0];
    first->next=NULL;
    last=first;
    for(i=1;i<n;i++)
    {
        t=(struct node*)malloc(sizeof(struct node));
        t->data=arr[i];
        t->next=NULL;
        last->next=t;
        last=t;
    }
}
void display(struct node *p)
{
    while(p!=NULL)
    {
        printf("%d-> ",p->data);
        p=p->next;
    }
}
void insert(struct node *p,int position,int value)
{
    struct node *t;
    t=(struct node*)malloc(sizeof(struct node));
    t->data=value;
    if(position==0)
    {
        t->next=first;
        first=t;
    }
    else
    {
        for(int i=0;i<position-1;i++)
        {
            p=p->next;
        }
        t->next=p->next;
        p->next=t;
    }
}
int main()
{
    int arr[]={5,10,15};
    create(arr,3);
    insert(first,1,35);
    display(first);
    return 0;
}
