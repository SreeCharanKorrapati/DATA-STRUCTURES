#include<stdio.h>
#include<stdlib.h>
struct node
{
    struct node * prev;
    int data;
    struct node * next;
}*first=NULL;
void create(int arr[],int n)
{
    struct node * t, *last;
    first=(struct node*)malloc(sizeof(struct node));
    first->data=arr[0];
    first->next=NULL;
    last=first;
    for(int i=1;i<n;i++)
    {
        t=(struct node*)malloc(sizeof(struct node));
        t->data=arr[i];
        t->prev=last;
        t->next=last->next;
        last->next=t;
        last=t;
    }
}
void display(struct node *p)
{
    while(p!=NULL)
    {
        printf("%d<->",p->data);
        p=p->next;
    }
}
void insert(struct node *p,int pos,int n)
{
    struct node*t;
    t=(struct node*)malloc(sizeof(struct node));
    t->data=n;
    t->next=t->prev=NULL;
    if(pos==0)
    {
        t->next=first;
        first->prev=t;
        first=t;
    }
    else
    {
        for(int i=0;i<pos-1;i++)
        {
            p=p->next;
        }
        t->prev=p;
        t->next=p->next;
        if(p->next)
        {
            p->next->prev=t;
        }
        p->next=t;
    }
}
int main()
{
    int arr[]={5,10,15,20,25};
    create(arr,5);
    insert(first,3,16);
    display(first);
    return 0;
}
