#include <stdio.h>
#include <stdlib.h>
struct node
{
    int data;
    struct node * next;
}*first=NULL;
void create(int arr[],int n)
{
    struct node * t, *last;
    first=(struct node*)malloc(sizeof(struct node));
    first->data=arr[0];
    first->next=NULL;
    last=first;
    for(int i=1;i<n;i++)
    {
        t=(struct node*)malloc(sizeof(struct node));
        t->data=arr[i];
        t->next=NULL;
        last->next=t;
        last=t;
    }
}
int issorted(struct node *p)
{
    p=first;
    int min = -20000;
    while(p!=NULL)
    {
        if(p->data<min)
        {
            return 0;
            break;
        }
        min=p->data;
        p=p->next;
    }
    return 1;
}
int main()
{
    int arr[]={5,10,35,20,25};
    create(arr,5);
    printf("%d ",issorted(first));
    return 0;
}
