#include <stdio.h>
#include <stdlib.h>
struct node
{
    int data;
    struct node * next;
}*first=NULL;
void create(int arr[],int n)
{
    int i;
    struct node*t,*last;
    first=(struct node*)malloc(sizeof(struct node));
    first->data=arr[0];
    first->next=NULL;
    last=first;
    for(i=1;i<n;i++)
    {
        t=(struct node*)malloc(sizeof(struct node));
        t->data=arr[i];
        t->next=NULL;
        last->next=t;
        last=t;
    }
}
void display(struct node *p)
{
    while(p!=NULL)
    {
        printf("%d-> ",p->data);
        p=p->next;
    }
}
void search(struct node *p,int key)
{
    while(p!=NULL)
    {
        if(p->data!=key)
        {
            p=p->next;
        }
        else
        {
            printf("\nEntered key is : %d ",key);
            printf("\nElement found .. ");
            break;
        }
    }
}
int main()
{
    int arr[]={5,10,15,20,25};
    create(arr,5);
    display(first);
    search(first,15);
    return 0;
}
