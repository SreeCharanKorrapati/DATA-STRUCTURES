#include<stdio.h>
int insertionsort(int arr[],int n)
{
    int i,j,x,temp;
    for(i=n;i>=0;i--)
    {
        for(j=i-1;j>=0;j--)
        {
            x=arr[i];
            if(arr[j]>arr[i])
            {
                temp=arr[j];
                arr[j]=arr[i];
                arr[i]=temp;
            }
        }
    }
    for(i=0;i<n;i++)
    {
        printf("%d ",arr[i]);
    }
    return 0;
}
int main()
{
    int arr[]={2,34,5,64,3,7};
    insertionsort(arr,6);
    return 0;
}
