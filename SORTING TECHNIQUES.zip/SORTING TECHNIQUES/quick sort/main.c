#include<stdio.h>
int partition(int a[],int l,int h)
{
     int pivot=a[l],temp,temp1;
     int i=l,j=h;
     do
     {
         do{i++;}while(a[i]<=pivot);
         do{j--;}while(a[j]>pivot);
         if(i<j)
         {
             temp=a[i];
             a[i]=a[j];
             a[j]=temp;
         }
     }while(i<j);
     temp1=a[l];
         a[l]=a[j];
         a[j]=temp1;
     return j;
}
void  quicksort(int arr[],int l,int h)
{
    int j;
    if(l<h)
    {
        j=partition(arr,l,h);
        quicksort(arr,l,j);
        quicksort(arr,j+1,h);
    }
}
int main()
{
    int arr[]={4,43,53,2,52,1,2,7,65535};
    quicksort(arr,0,9);
    for(int i=0;i<9;i++)
    {
        printf("%d ",arr[i]);
    }
    return 0;
}
