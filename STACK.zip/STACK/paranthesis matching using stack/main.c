#include <stdio.h>
#include <stdlib.h>

struct stack {
    int size;
    int top;
    char *S;
};

void create(struct stack *st) {
    printf("Enter the size of the stack : ");
    scanf("%d", &st->size);
    st->top = -1;
    st->S = (char *)malloc(st->size * sizeof(char));
}

void push(struct stack *st, char x) {
    if (st->top == st->size - 1) {
        printf("Stack overflow...");
    } else {
        st->top++;
        st->S[st->top] = x;
    }
}

char pop(struct stack *st) {
    char x = -1;
    if (st->top == -1) {
        printf("Stack underflow....");
    } else {
        x = st->S[st->top];
        st->top--;
    }
    return x;
}

void isbalanced(char *expr) {
    struct stack st;
    create(&st);
    for (int i = 0; expr[i] != '\0'; i++) {
        if (expr[i] == '(') {
            push(&st, expr[i]);
        } else if (expr[i] == ')') {
            if (st.top != -1) {
                pop(&st);
            } else {
                printf("Not valid...");
                break;
            }
        } else {
            continue;
        }
    }
    if (st.top == -1) {
        printf("Valid..");
    } else {
        printf("Invalid..");
    }
}

void display(struct stack st) {
    for (int i = st.top; i >= 0; i--) {
        printf("%c ", st.S[i]);
    }
}

int main() {
    char *expr = "((a+b)*(c+d))";
    isbalanced(expr);
    return 0;
}
