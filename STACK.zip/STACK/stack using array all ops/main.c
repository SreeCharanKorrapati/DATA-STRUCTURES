#include<stdio.h>
#include<stdlib.h>
struct stack
{
    int size;
    int top;
    int *S;
};
void create(struct stack *st)
{
    printf("Enter the size of the stack : \n");
    scanf("%d",&st->size);
    st->top=-1;
    st->S=(int *)malloc(st->size*sizeof(int));
}
void display(struct stack st)
{
    int i;
    for(i=st.top;i>=0;i--)
    {
        printf("%d \n",st.S[i]);
    }
}
void push(struct stack *st,int x)
{
    if(st->top==st->size-1)
    {
        printf("Stack overflow...");
    }
    else
    {
        st->top++;
        st->S[st->top]=x;
    }
}
int  pop(struct stack *st)
{
    int x=-1;
    if(st->top==-1)
    {
        printf("Stack underflow...");
    }
    else
    {
        x=st->S[st->top];
        st->top--;
    }
    return x;
}
int peek(struct stack st,int index)
{
    int x = -1;
    if(st.top-index+1<0)
    {
        printf("Invalid index...");
    }
    else
    {
        x=st.S[st.top-index+1];
    }
    return x;
}
int stacktop(struct stack st)
{
    if(st.top==-1)
    {
        return -1;
    }
    else
    {
        return st.S[st.top];
    }
}
void isempty(struct stack st)
{
    if(st.top==-1)
    {
        printf("Stack is empty");
    }
    else
    {
        printf("Stack is not empty");
    }
}
void isfull(struct stack st)
{
    if(st.top==st.size-1)
    {
        printf("Stack is full..");
    }
    else
    {
        printf("Stack is not full ..");
    }
}
int main()
{
    struct stack st;
    create(&st);
    push(&st,10);
    push(&st,20);
    push(&st,30);
    push(&st,40);
    push(&st,50);
    printf("popped element : %d\n",pop(&st));
    display(st);
    printf("peek element : %d \n",peek(st,3));
    printf("Top element : %d \n",stacktop(st));
    isfull(st);
    isempty(st);
    return 0;
}
