#include <stdio.h>
#include <stdlib.h>
struct term
{
    int coeff;
    int exp;
};
struct poly
{
    int n;
    struct term *t;
};
void create(struct poly *p)
{
    int i;
    printf("Enter the value of n : ");
    scanf("%d",&p->n);
    p->t=(struct term*)malloc(p->n*sizeof(struct term));
    for(i=0;i<p->n;i++)
    {
        scanf("%d %d ",&p->t[i].coeff,&p->t[i].exp);
    }
}
void display(struct poly p)
{
    int i;
    for(i=0;i<p.n;i++)
    {
        printf("%dx^%d+",p.t[i].coeff,p.t[i].exp);
    }
    printf("\n");
}
int main()
{
    struct poly p;
    create(&p);
    display(p);
    return 0;
}
