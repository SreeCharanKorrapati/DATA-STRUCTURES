#include<iostream>
using namespace std;

int main() {
    char a[100], b[100];
    int n, m;
    int h[256] = {0};  // Increase the size of the array

    cout << "Enter the size of string 1: ";
    cin >> n;
    cout << "Enter the size of string 2: ";
    cin >> m;

    if (n != m) {
        cout << "Both are not anagrams...";
    } else {
        cout << "Enter string 1: ";
        for (int i = 0; i < n; i++) {
            cin >> a[i];
        }
        cout << "Enter string 2: ";
        for (int j = 0; j < m; j++) {
            cin >> b[j];
        }

        for (int i = 0; i < n; i++) {
            h[a[i]] += 1;  // Use characters directly as indices
        }
        for (int i = 0; i < m; i++) {
            h[b[i]] -= 1;
        }

        bool isAnagram = true;
        for (int i = 0; i < 256; i++) {  // Check the entire character set
            if (h[i] != 0) {
                isAnagram = false;
                break;
            }
        }

        if (isAnagram) {
            cout << "Anagram..";
        } else {
            cout << "Not an anagram...";
        }
    }

    return 0;
}
