#include <iostream>
#include<stdio.h>
using namespace std;

int main()
{
    int arr[100],length,size,i,index;
    cout << "Enter the size of array : " << endl;
    cin >> size;
    cout << "Enter the length of array : " << endl;
    cin >> length;
    cout << "Enter the elements of the array : " << endl;
    for(i=0;i<length;i++)
    {
        cin >> arr[i];
    }
    cout << "Enter the index of element you want to delete " << endl;
    cin >> index;
    if(index>length)
    {
        cout << "Enter proper index...";
    }
    else
    {
        int x=arr[index];
        for(i=index;i<length-1;i++)
        {
            arr[i]=arr[i+1];
        }
        length--;
        cout << "The new array is : " << endl;
        for(i=0;i<length;i++)
        {
            cout << arr[i] << endl;
        }
    }
    return 0;
}
