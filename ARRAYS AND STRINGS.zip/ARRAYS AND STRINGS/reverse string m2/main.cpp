#include <iostream>

using namespace std;

int main()
{
    char arr[100],t;
    int n;
    cout << "Enter the size of the string : ";
    cin >> n;
    cout << "Enter the string : ";
    for(int i=0;i<n;i++)
    {
        cin >> arr[i];
    }
    arr[n]='\0';
    cout << "Reversing the string : " ;
    for(int i=0,j=n-1;i<j;i++,j--)
    {
        t=arr[i];
        arr[i]=arr[j];
        arr[j]=t;
    }
    for(int i=0;i<n;i++)
    {
        cout << arr[i];
    }
    return 0;
}
