#include<iostream>
using namespace std;
int main()
{
    int arr[100],n,i,j;
    cout << "Enter the number of elements of the array : " << endl;
    cin >> n;
    cout << "Enter the elements " << endl;
    for(i=0;i<n;i++)
    {
        cin >> arr[i];
    }
    for(i=0,j=n-1;i<j;i++,j--)
    {
        while(arr[i]<0)
        {
            i++;
        }
        while(arr[j]>0)
        {
            j--;
        }
        if(i<j)
        {
            swap(arr[i],arr[j]);
        }
    }
    for(i=0;i<n;i++)
    {
        cout << arr[i];
    }
    return 0;
}
