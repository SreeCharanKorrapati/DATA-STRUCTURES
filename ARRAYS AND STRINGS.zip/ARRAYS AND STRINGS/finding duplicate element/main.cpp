#include<iostream>
using namespace std;
int main()
{
    int arr[100],i,n;
    int lastduplicate = 0;
    cout << "Enter the value of n : " << endl;
    cin >> n;
    for(i=0;i<n;i++)
    {
        cin >> arr[i];
    }
    for(i=0;i<n;i++)
    {
        if(arr[i] == arr[i+1] && lastduplicate != arr[i])
        {
            cout << arr[i] << endl;
            lastduplicate = arr[i];
        }
    }
    return 0;
}
