#include<iostream>
#include<stdio.h>
#include<stdlib.h>
using namespace std;
int main()
{
    int arr[100],length,index,element,size;
    cout << "Enter the size of the array " << endl;
    cin >> size;
    cout << "Enter the number of elements : " << endl;
    cin >> length;
    cout << "Enter the elements of the array : " << endl;
    for(int i=0;i<length ; i++)
    {
        cin >> arr[i];
    }
    cout << "Enter the index where you want to insert the new element : " << endl;
    cin >> index;
    if(index > size)
    {
        cout << "Enter valid index...";
    }
    else
    {
        cout << "Enter the new element : "<<endl;
        cin >> element;
        if(index>length && index<size)
        {
            arr[index]=element;
        }
        else
        {
            for(int i=length;i>index;i--)
            {
                arr[i]=arr[i-1];
            }
            arr[index]= element;
            length++;
            cout << "New array is : " << endl;
            for(int i=0;i<length;i++)
            {
                cout <<arr[i] << endl;
            }
        }
    }
    return 0;
}
