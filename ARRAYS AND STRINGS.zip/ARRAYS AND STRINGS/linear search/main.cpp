#include<iostream>
#include<stdio.h>
using namespace std;
int main()
{
    int arr[100],i,length,size,key;
    cout << "Enter the size of the array : " << endl;
    cin >> size;
    cout << "Enter the length of array : " << endl;
    cin >> length;
    cout << "Enter the elements of the array : " << endl;
    for(i=0;i<length ; i++)
    {
        cin >> arr[i];
    }
    cout << "Enter the element you want to search : " << endl;
    cin >> key;
    for(i=0;i<length;i++)
    {
        if(arr[i]==key)
        {
            cout << "Element found at the index : " << i;
        }
        return -1;
    }
    return 0;
}
