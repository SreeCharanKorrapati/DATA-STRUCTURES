#include<iostream>
using namespace std;
int main()
{
    int arr[100],i,size,n,key;
    cout << "Enter the size of the array : " << endl;
    cin >> size;
    cout << "Enter the number of elements :" << endl;
    cin >> n;
    cout << "Enter elements in sorted order : " << endl;
    for(i=0;i<n;i++)
    {
        cin >> arr[i];
    }
    cout << "Enter new element : " << endl;
    cin >> key;
    int j = n-1;
    while(arr[j]>key)
    {
        arr[j+1] = arr[j];
        j--;
    }
    arr[j+1] = key;
    cout << "Updated array :  " << endl;
    for(i=0;i<n+1;i++)
    {
        cout << arr[i];
    }
    return 0;

}
