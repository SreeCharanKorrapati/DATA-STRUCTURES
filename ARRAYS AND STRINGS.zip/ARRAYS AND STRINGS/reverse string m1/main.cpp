#include <iostream>
using namespace std;

int main()
{
    char arr[100], brr[100];
    int n;

    cout << "Enter the size of the string: ";
    cin >> n;

    cout << "Enter the string: ";
    for (int i = 0; i < n; i++)
    {
        cin >> arr[i];
    }
    arr[n] = '\0';

    for (int j = 0, i = n - 1; i >= 0; j++, i--)
    {
        brr[j] = arr[i];
    }
    brr[n] = '\0';

    cout << "Reverse of string is ";
    for (int j = 0; j < n; j++)
    {
        cout << brr[j];
    }
    return 0;
}
