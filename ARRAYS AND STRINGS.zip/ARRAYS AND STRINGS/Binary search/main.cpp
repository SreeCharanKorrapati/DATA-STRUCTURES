#include<iostream>
using namespace std;
struct array
{
    int a[100];
    int length;
    int size;
};
int binarysearch(struct array arr,int key)
{
    int l,mid,h;
    l=0;
    h=arr.length-1;
    while(l<=h)
    {
        mid=(l+h)/2;
        if(arr.a[mid]==key)
        {
            return mid;
        }
        else if(key <= arr.a[mid])
        {
            h = mid - 1;
        }
        else
        {
            l = mid + 1;
        }
    }
    return -1;
}
int main()
{
    struct array arr={{1,2,3,4,5},5,10};
    cout << binarysearch(arr,1);
    return 0;
}
